package com.programs_practice;

import java.security.PublicKey;
import java.util.Scanner;



public class Main {

    public static void main(String[] args) {

/*
        Scanner s = new Scanner(System.in);
        for(int i = 1; i<=4; i++){
            System.out.println("ENTER AN INTEGER NUMBER ");
            int t = s.nextInt();
            System.out.println(t);
        }
*/
        //===========================================================================================

/*        Scanner t = new Scanner(System.in);
        System.out.println("enter an integer do u want ");
        int num1 = t.nextInt();
        for (int i = 0; i<=10; i++)
            System.out.println(num1 + "x" +(i)  +" = " + (num1*(i+1)) );
            */

        // ============================================================================================


/*        Scanner t = new Scanner(System.in);
        System.out.println("enter an value do u want ");
        double radius = t.nextDouble();
        double perimeter = 2*Math.PI*radius;
        double area = Math.PI*radius*radius;
        System.out.println( "perimeter is ="+perimeter );
        System.out.println( "area is ="+ area );*/

        // ================================================================================================
/*
        Scanner t = new Scanner(System.in);
        System.out.println("enter an value do u want ");
        int number1  = t.nextInt();
        System.out.println("enter an value do u want ");
        int number2  = t.nextInt();
        if ( number1 == number2 )
            System.out.printf("%d == %d\n", number1 , number2);
        if ( number1 != number2 )
            System.out.printf("%d != %d\n", number1 , number2);
        if ( number1 <= number2 )
            System.out.printf("%d <= %d\n", number1 , number2);
        if ( number1 >= number2 )
            System.out.printf("%d >= %d\n", number1 , number2);
        if ( number1 > number2 )
            System.out.printf("%d > %d\n", number1 , number2);
        if ( number1 < number2 )
            System.out.printf("%d < %d\n", number1 , number2);
*/
        // =============================================================================================

        Scanner t = new Scanner(System.in);
        System.out.println("enter an value do u want ");
        int n = t.nextInt();
        System.out.println("sum of digits is =" + sumDigits(n));
    }


    public static int sumDigits(int n) {
        int sum = 0;
        while (n != 0) {
            sum = sum + n % 10;
            n = n / 10;

        }
        return sum;


  //==============================================================================================
/*
        Scanner t = new Scanner(System.in);
        System.out.println("enter an value do u want ");
        double s = t.nextDouble();
        System.out.print("the area of hexagone is =" + hexagoneArea(s) +"\n");
    }


    public static double hexagoneArea (double s) {
        return (6*(s*s))/ (4*Math.tan(Math.PI/6));
    }

*/

    }

    }