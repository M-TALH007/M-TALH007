package polymorphism;

public class bank {
    public void transferMoney(double fromAccount,  double toAccount,double amount){
        // ... logic
        System.out.println("amount succesfully transfered");

    }
}
