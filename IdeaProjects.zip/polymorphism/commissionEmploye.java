package polymorphism;

public class commissionEmploye extends employe {
    private double rate;
    private double sales;

    public commissionEmploye(int id, String name, double rate, double sales) {
        super(id, name);
        this.rate = rate;
        this.sales = sales;
    }

    @Override
    public double earning() {
        return getRate()*getSales();
    }

    @Override
    public String toString() {
        return "commissionEmploye{" +
                "rate=" + rate +
                ", sales=" + sales +
                '}';
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    public double getSales() {
        return sales;
    }

    public void setSales(double sales) {
        this.sales = sales;
    }
}
