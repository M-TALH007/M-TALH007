package polymorphism;

public class employe {
    private int id;
    private String name;
    private double bankNumber;
    public employe(int id, String name) {
        this.id = id;
        this.name = name;
    }
    public double earning(){
        return 0;
    }

    public double getBankNumber() {
        return bankNumber;
    }

    public void setBankNumber(double bankNumber) {
        this.bankNumber = bankNumber;
    }

    @Override
    public String toString() {
        return "employe{" +
                "id=" + id +
                ", name='" + name + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
