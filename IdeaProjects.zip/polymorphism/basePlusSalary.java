package polymorphism;

public class basePlusSalary extends commissionEmploye {
    private double bSalary;

    public basePlusSalary(int id, String name, double rate, double sales, double bSalary) {
        super(id, name, rate, sales);
        this.bSalary = bSalary;
    }

    public double getbSalary() {
        return bSalary;
    }

    public void setbSalary(double bSalary) {
        this.bSalary = bSalary;
    }

    @Override
    public String toString() {
        return "basePlusSalary{" +
                "bSalary=" + bSalary +
                '}';
    }

    @Override
    public double earning() {
        return super.earning()+getbSalary();
    }
}
