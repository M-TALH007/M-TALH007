package polymorphism;

public class test {
    public static void main(String[] args) {
        Accounts a = new Accounts();
        commissionEmploye ce = new commissionEmploye(1,"ali",0.5,120000);
        ce.setBankNumber(23);
        a.acountIntoAccount(ce);
        a.toString();




        hourlyEmploye he = new hourlyEmploye(2,"talha",6,12);
        he.setBankNumber(12);
        a.acountIntoAccount(he);
        a.toString();
    }
}
