package polymorphism;

public class perWEEK extends employe  {
    private double rateperPiece;
    private  double piece;

    public perWEEK(int id, String name, double rateperPiece, double piece) {
        super(id, name);
        this.rateperPiece = rateperPiece;
        this.piece = piece;
    }

    @Override
    public String toString() {
        return "perWEEK{" +
                "rateperPiece=" + rateperPiece +
                ", piece=" + piece +
                '}';
    }

    @Override
    public double earning() {
        return getPiece()*getRateperPiece();
    }

    public double getRateperPiece() {
        return rateperPiece;
    }

    public void setRateperPiece(double rateperPiece) {
        this.rateperPiece = rateperPiece;
    }

    public double getPiece() {
        return piece;
    }

    public void setPiece(double piece) {
        this.piece = piece;
    }
}
