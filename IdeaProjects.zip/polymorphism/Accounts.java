package polymorphism;

public class Accounts {
    final private static double companyBankNumber=100;
    bank b = new bank();
    public void acountIntoAccount(employe e){
        if (e.getBankNumber() < 0)
            System.out.println("money Not Transfer");

        b.transferMoney(companyBankNumber,e.getBankNumber(),e.earning());
    }

}
