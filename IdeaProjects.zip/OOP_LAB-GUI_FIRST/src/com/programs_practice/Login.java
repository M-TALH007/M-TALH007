package com.programs_practice;
import java.awt.*;
import javax.swing.SwingConstants;


import javax.swing.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Scanner;

public class Login extends JFrame{
        private String username= "";
        private String password="123";
        private final JLabel label1;
        private final JLabel label2;
        private final JTextField textField;
        private final JPasswordField passwordField;
        private final JButton button;

  public Login(){
      super("login Form");
      setLayout((new FlowLayout()));
    label1 = new JLabel("username");
    add(label1);
    textField=new JTextField(15);
     add(textField);
      label2 = new JLabel("password");
      add(label2);
      passwordField=new JPasswordField(5);
      add(passwordField);

      button = new JButton("login");
      add(button);
      button.addActionListener(
              new ActionListener() {
                  @Override
                  public void actionPerformed(ActionEvent e ) {
                      String s=textField.getText();
                      String s1=passwordField.getText();
                      if(s.contains(username)&&s1.contains(password)){
                          JOptionPane.showMessageDialog(null,"the password is correct");
                      }
                      else
                          JOptionPane.showMessageDialog(null,"incorrect");
                  }
              }
      );

  }
}


