package com.programs_practice;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

class RadioButton extends JFrame {
    private final JTextField t1;
    private final JRadioButton b1;
    private final JRadioButton b2;
    private  final Font p1;
    private final Font p2;

     public RadioButton() {
         super("RADIO BUTTON");
         setLayout(new FlowLayout());
         t1 = new JTextField("my writng is ", 10);
         b1 = new JRadioButton("Bold", true);
         b2 = new JRadioButton("Italic", false);
         add(t1);
         add(b1);
         add(b2);
         ButtonGroup group = new ButtonGroup();

         b1.addItemListener(group);
         b2.addItemListener(group);

         p1 = new Font("Arial",Font.BOLD,14);
         p2 = new Font("Arial",Font.ITALIC,14);
         t1.setFont(p1);


     }
      private class ButtonGroup implements ItemListener{





          @Override
          public void itemStateChanged(ItemEvent e) {

          }
      }
}
