/*
package com.programs_practice;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class calculator extends JFrame {
    private  final JTextField t1;
    private final JTextField t2;
    private final JLabel l1;
    private final JLabel l2;
    private final JButton b1;
    private final JButton b2;
    public calculator(){
        super("CALCULATOR");
        setLayout(new FlowLayout());
        l1=new JLabel("enter First Integer Number");
        t1=new JTextField(10);
        l2=new JLabel("enter 2nd Integer Number");
        t2=new JTextField(10);
        b1=new JButton("+");
        b2=new JButton("-");
        add(l1);
        add(t1);
        add(l2);
        add(t2);
        add(b1);
        add(b2);
        Bu1 h= new Bu1();
        b1.addActionListener(h);
        b2.addActionListener(h);


    }
    private class Bu1 implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if(e.getSource()==b1){
                int a = Integer.parseInt(t1.getText());
                int b = Integer.parseInt(t2.getText());
                int c= a+b;
                JOptionPane.showMessageDialog(null,"the sum is "+c);
            }
            if(e.getSource()==b2){
                int a = Integer.parseInt(t1.getText());
                int b = Integer.parseInt(t2.getText());
                int c= a-b;
                JOptionPane.showMessageDialog(null,"the sum is "+c);
            }
        }
    }



}


*/
