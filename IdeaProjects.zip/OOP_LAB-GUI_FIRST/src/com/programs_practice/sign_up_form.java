package com.programs_practice;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class sign_up_form extends JFrame {
    private JLabel header;
    private JLabel userID;
    private JLabel userName;
    private JLabel password;
    private JLabel confirm;
    private JTextField userIDField;
    private JTextField userNameField;
    private JPasswordField passwordField;
    private JPasswordField confirmField;
    private JButton loginButton;
    private JLabel gender;
    private JComboBox genderComboBox;
    private JRadioButton zeroToTen;
    private JRadioButton tenToTwenty;
    private JRadioButton twentyToThirty;
    private JCheckBox cricket;
    private JCheckBox badminton;
    private JCheckBox racing;
    private JCheckBox gaming;
    ButtonGroup ageGroup;
    public sign_up_form(){
        super("My Login Frame");
        setLayout(new FlowLayout());
        Box vBox = Box.createVerticalBox();
        add(vBox);
        header = new JLabel("Login Form");
        header.setFont(new Font("Aerial", 30, Font.BOLD));
        vBox.add(header);
        Box b1 =  Box.createHorizontalBox();
        vBox.add(b1);
        userID = new JLabel("User ID");
        b1.add(userID);
        userIDField = new JTextField(15);
        b1.add(userIDField);
        Box b2 =  Box.createHorizontalBox();
        vBox.add(b2);
        userName = new JLabel("User Name");
        b2.add(userName);
        userNameField = new JTextField(15);
        b2.add(userNameField);
        Box b3 =  Box.createHorizontalBox();
        vBox.add(b3);
        password = new JLabel("Password");
        b3.add(password);
        passwordField = new JPasswordField(15);
        b3.add(passwordField);
        Box b4 =  Box.createHorizontalBox();
        vBox.add(b4);
        confirm = new JLabel("Confirm Password");
        b4.add(confirm);
        confirmField = new JPasswordField(15);
        b4.add(confirmField);
        Box b5 =  Box.createHorizontalBox();
        vBox.add(b5);
        gender = new JLabel("Gender");
        b5.add(gender);
        genderComboBox = new JComboBox();
        genderComboBox.addItem("Male");
        genderComboBox.addItem("Female");
        genderComboBox.addItem("Talha");
        b5.add(genderComboBox);
        vBox.add(new JLabel("Age"));
        Box ageRadioBox = Box.createHorizontalBox();
        vBox.add(ageRadioBox);
        zeroToTen = new JRadioButton("0 - 10");
        ageRadioBox.add(zeroToTen);
        tenToTwenty = new JRadioButton("10-20");
        ageRadioBox.add(tenToTwenty);
        twentyToThirty = new JRadioButton("20-30");
        ageRadioBox.add(twentyToThirty);
        ageGroup = new ButtonGroup();
        ageGroup.add(zeroToTen);
        ageGroup.add(tenToTwenty);
        ageGroup.add(twentyToThirty);
        vBox.add(new JLabel("Hobbies"));
        Box hobbiesCheckBox = Box.createHorizontalBox();
        vBox.add(hobbiesCheckBox);
        cricket = new JCheckBox("Cricket");
        badminton = new JCheckBox("Badminton");
        racing = new JCheckBox("Racing");
        gaming = new JCheckBox("Gaming");
        hobbiesCheckBox.add(cricket);
        hobbiesCheckBox.add(badminton);
        hobbiesCheckBox.add(racing);
        hobbiesCheckBox.add(gaming);
        loginButton = new JButton("Login");
        vBox.add(loginButton);
        loginButton.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                boolean passwordMatches = passwordField.getText().equals(confirmField.getText());
                boolean passwordLengthMatches = passwordField.getText().length() >= 8;
                if(!passwordMatches){
                    JOptionPane.showMessageDialog(null, "Password Does Not match");
                }else if(!passwordLengthMatches){
                    JOptionPane.showMessageDialog(null, "Password length should be greater than 8");
                }else{
                    int id =Integer.parseInt(userIDField.getText());
                    String name = userNameField.getText();
                    String pwd = passwordField.getText();
                    String gender = (String) genderComboBox.getSelectedItem();
                    String age;
                    if(zeroToTen.isSelected())
                        age = "0 - 10";
                    else if(tenToTwenty.isSelected())
                        age = "10 - 20";
                    else
                        age = "20 - 30";
                    String hobbies = "";
                    if(cricket.isSelected())
                        hobbies += "Cricket\n";
                    if(badminton.isSelected())
                        hobbies += "Badminton\n";
                    if(racing.isSelected())
                        hobbies += "Racing\n";
                    if(gaming.isSelected())
                        hobbies += "Gaming\n";
                    String output = String.format("ID %s%nName %s%n Password %s%nGender %s%nAge %s%nHobbies: %n%s", id, name, pwd, gender, age, hobbies);
                    JOptionPane.showMessageDialog(null, output);
                }
            }
        });
    }
}
