package com.programs_practice;

import javax.swing.*;

public class Main {

    public static void main(String[] args) {
/*      Login l = new Login();
        l.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        l.setSize(300,120);
         l.setVisible(true);*/
        //==================================================================
        /*calculator l = new calculator();
        l.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        l.setSize(300,120);
        l.setVisible(true);*/
        //================================================================
      /*  checkBox c= new checkBox();
        c.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c.setSize(300,300);

       c.setVisible(true);*/
//====================================================================
/*        RadioButton c= new RadioButton();
        c.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        c.setSize(300,300);
        c.setVisible(true);    */
        sign_up_form s = new sign_up_form();
        s.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        s.setSize(300,300);
        s.setVisible(true);
    }

}
