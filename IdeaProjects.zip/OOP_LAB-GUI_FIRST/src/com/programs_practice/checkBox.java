package com.programs_practice;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class checkBox extends JFrame {
    private final JTextField t1;
    private final JCheckBox b1;
    private final JCheckBox b2;
     public checkBox(){
         super("CHECK BOX");
         setLayout(new FlowLayout());
         t1 = new JTextField("my writng is ",10);
         b1 = new JCheckBox("Bold");
         b2 = new JCheckBox("Italic");
         add(t1);
         add(b1);
         add(b2);
         Bu1 h= new Bu1();
         b1.addItemListener(h);
         b2.addItemListener(h);
     }
    private class Bu1 implements ItemListener {
        @Override
        public void itemStateChanged(ItemEvent e) {
            Font font = null;
            if (b1.isSelected() && b2.isSelected())
                font = new Font("Serif", Font.BOLD + Font.ITALIC, 14);
            else if (b1.isSelected())
                font = new Font("Serif", Font.BOLD, 14);
            else if (b2.isSelected())
                font = new Font("Serif", Font.ITALIC, 14);
            else
                font = new Font("Serif", Font.PLAIN, 14);
            t1.setFont(font);

        }
    }

}
