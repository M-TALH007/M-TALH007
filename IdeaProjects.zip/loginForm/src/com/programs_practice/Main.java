package com.programs_practice;
import javax.swing.*;
public class Main {

    public static void main(String[] args) {
        Login l = new Login();
        l.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        l.setSize(300,120);
        l.setVisible(true);
    }
}


