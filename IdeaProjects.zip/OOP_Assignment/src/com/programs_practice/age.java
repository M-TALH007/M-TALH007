package com.programs_practice;

public enum age {
    YOUNG(0.06,"young"),ADULTS(0.07,"adult"),SENIOR(0.08,"senior");
      private double profit;
      private String name;

    age(double profit, String name) {
        this.profit = profit;
        this.name = name;
    }

    public String getName() {
        return name;
    }
    public double getProfit() {
        return profit;
    }
}
