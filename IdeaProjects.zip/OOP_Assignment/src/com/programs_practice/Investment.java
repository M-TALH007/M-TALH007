package com.programs_practice;
import java.util.Scanner;

public class Investment extends Earning_Account{
    years type;
    public Investment(int age, double amount, String name, int id, boolean zakat, boolean fil) {
        super(age, amount, name, id, zakat, fil);
       type=setType();
    }
    public years setType() {
        Scanner input = new Scanner(System.in);
        int choice;
        System.out.println("enter a choice\n1- chose 1 year \n2- chose 3 year \n" +"3- chose 5 year ");
        choice = input.nextInt();
        switch (choice) {
            case 1:
                return years.ONE;
            case 2:
                return years.THREE;
            case 3:
                return years.FIVE;
        }
        return null;
    }
    @Override
    public void withdraw(double WAmount) {
        double surCharge = WAmount*0.04;
        super.setAmount(super.getAmount()-WAmount-surCharge);
        System.out.println("Amount Withdraw : "+WAmount);
        System.out.println("SurCharge Amount : "+surCharge);
    }
    @Override
    public void deposit(double DAmount) {
        super.setAmount(super.getAmount()+DAmount);
        System.out.println("Amount Deposit "+DAmount);
    }
    @Override
    public double balanceCheck() {
        return getAmount();
    }



    @Override
    public void reinvestProfit(double profit){
        Scanner input = new Scanner(System.in);
        System.out.println("\nDo you want to reinvest the earnings?\nenter 1 to reinvest or enter 0 if not");
        int choice = input.nextInt();
        if(choice == 1){
            deposit(profit);
        }
    }
    @Override
    public double zakatDeduction(double ZAmount) {
        ZAmount = super.getAmount()-(super.getAmount()*0.025);
        return ZAmount;
    }
    @Override
    public double TotalEarning() {
        Scanner input = new Scanner(System.in);
        double TotalProfit = super.getAmount() * super.getCategory().getProfit();
        double amountIncreasePerYear = 0;
        for (int i = 0; i < type.getYears(); i++) {
            amountIncreasePerYear = super.getAmount() * type.getProfit();
            super.setAmount(super.getAmount()+amountIncreasePerYear);
            TotalProfit += amountIncreasePerYear;
        }
        if(super.isFil()){
            TotalProfit = TotalProfit - (TotalProfit * 0.15);
        }
        else
            TotalProfit = TotalProfit - (TotalProfit * 0.25);

        return TotalProfit;
    }

    @Override
    public double deductZakat(double total) {
        return 0;
    }

    @Override
    public String toString() {
        return "\nInvestment{" +
                super.toString()+
                "category=" + category +
                ", type=" + type +
                '}';
    }
}
