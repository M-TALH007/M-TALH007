package com.programs_practice;
import java.util.Scanner;

public class Saving extends Earning_Account{
    public Saving(int age, double amount, String name, int id, boolean zakat, boolean fil) {
        super(age, amount, name, id, zakat, fil);
    }

    @Override
    public void withdraw(double WAmount) {
        super.setAmount(super.getAmount()-WAmount);
        System.out.println("Amount Withdraw : "+WAmount);

    }

    @Override
    public void deposit(double DAmount) {
        super.setAmount(super.getAmount()+DAmount);
        System.out.println("Amount Deposit "+DAmount);
    }

    @Override
    public double balanceCheck() {
        return getAmount();
    }


    @Override
    public double zakatDeduction(double ZAmount) {
       ZAmount = super.getAmount()-(super.getAmount() * 0.025);
       return ZAmount;
    }

    @Override
    public double TotalEarning() {

        double totalProfit = super.getAmount() * super.getCategory().getProfit();

        if(super.isFil()){
            totalProfit = totalProfit - (totalProfit * 0.15);
        }
        else
            totalProfit = totalProfit - (totalProfit * 0.25);
        return totalProfit;
    }

    @Override
    public double deductZakat(double total) {
        return 0;
    }


    @Override
    public void reinvestProfit(double profitEarned){
        Scanner input = new Scanner(System.in);
        System.out.println(" \nDo you want to reinvest the earnings?\nPress 1 to reinvest or Press 0 if not");
        int choice = input.nextInt();
        if(choice == 1){
            deposit(profitEarned);
        }
    }

    @Override
    public String toString() {
        return "Saving{" +
                super.toString()+
                "category=" + category +
                '}';
    }

}
