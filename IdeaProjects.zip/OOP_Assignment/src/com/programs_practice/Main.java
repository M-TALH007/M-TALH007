package com.programs_practice;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {

        Account [] acc = new Account[]{
        new Current_Account(20,1200,"Talha",1,true),
        new Investment(21,1300,"Ali",2,true,true),
        new Saving(20,1400,"Ahmed",3,true,true)
        };



        /*
        ArrayList<Account> acc = new ArrayList<>();
        acc.add(new Current_Account(20,1200,"Talha",1,true));
        acc.add(new Investment(21,1300,"Ali",2,true,true));
        acc.add(new Saving(20,1400,"Ahmed",3,true,true));
        acc.add(new Saving(22,1600,"Bakr",4,true,true));
        acc.add(new Saving(23,1500,"Asnan",5,true,true));*/

        for(Account account:acc){
            System.out.println(account);
            double totalEarnings = account.TotalEarning();
            System.out.printf("Total Earnings: %.2f",totalEarnings);
            if(account instanceof Earning_Account){
                Earning_Account temp = (Earning_Account) account;
                temp.reinvestProfit(totalEarnings);
            }

        }
        System.out.printf("%n Profit Paid by the Bank: %.2f ",Account.totalProfit(acc));
    }
}
