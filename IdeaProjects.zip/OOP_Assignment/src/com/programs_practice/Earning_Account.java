package com.programs_practice;

public abstract class Earning_Account extends Account{
    private boolean fil;
    age category;
    public Earning_Account(int age, double amount, String name, int id,
                           boolean zakat, boolean fil) {
        super(age, amount, name, id, zakat);
        this.category = setAgeCategory();
        this.fil=fil;
    }
    public age getCategory() {
        return category;
    }
    public age setAgeCategory() {
        if(super.getAge()<30){
            return age.YOUNG;
        }
        else if(super.getAge()>=35 && super.getAge()<=50){
            return age.ADULTS;
        }
        else
            return age.SENIOR;
    }
    public boolean isFil() {
        return fil;
    }
    public void setFil(boolean fil) {
        this.fil = fil;
    }
    public abstract double TotalEarning();
    public abstract double deductZakat(double total);
    public abstract void reinvestProfit(double profitEarned);
    @Override
    public String toString() {
        return "Earning_Account{" +
                super.toString()+
                "fil=" + fil +
                ", category=" + category +
                '}';
    }
}
