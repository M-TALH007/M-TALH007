package com.programs_practice;

import java.awt.*;
import java.sql.SQLOutput;
import java.util.ArrayList;

public class ArrayListCollection {

    public static void main(String[] args) {
/*    ArrayList<String> items;
        items = new ArrayList<String>();
        items.add(0,"talha");
        items.add(1,"ali");
        for(int i =0;i<items.size();i++) {
            System.out.println( "through simle for loop: "+items.get(i));
        }
        System.out.println();
        for (String q : items)
        {
            System.out.println("through enhance for loop: "+q);
        }
        System.out.println("through display method");
        Display(items,"used for loop of enhanced");
        System.out.println();
        System.out.println("size "+ items.size());
        System.out.println();
        items.remove(1);
        System.out.println(items);
        items.remove("talha");
        System.out.println(items);
    }

    public static void Display(ArrayList<String> items,String header) {
        System.out.println(header);
        for (String item : items) {
            System.out.println(item);
        }*/
/*
     int[] grades={100,23,43,76,35,53,56,89,56,100};
        gradeBook myBook=new gradeBook("introduction to java programming",grades );
        System.out.printf("welcome to grade book for %s%n",myBook.getCourseName());
        myBook.processGrade();
*/
       /* int[]  array ={100,23,43,76,35,53,56,89,56,100};
        index ind=new index();
        index.max(array);
        index.min(array);*/
        staticVariable s1  =new staticVariable("talha",1);
        staticVariable s2  =new staticVariable("ahmed ",2);
        staticVariable s3  = new staticVariable("ali", 3);
        staticVariable s4  = new staticVariable("zohaib", 4);
        staticVariable s5 = new staticVariable("Mishal",5);
        staticVariable.father="falak Sher";
        System.out.println("one person  data");
        System.out.println("id id:"+s1.getId()+"\nname is : "+s1.getName());
        staticVariable.father();
        System.out.println();

        System.out.println("1st person's brother data");
        System.out.println("id id:"+s2.getId()+"\nname is : "+s2.getName());
        staticVariable.father();
        System.out.println();

        System.out.println("1st person's  2nd brother data");
        System.out.println("id id:"+s3.getId()+"\nname is : "+s3.getName());
        staticVariable.father();
        System.out.println();
        System.out.println();

        staticVariable.father="Allah dita";
        System.out.println("1st person czn  data");
        System.out.println("id id:"+s4.getId()+"\nname is : "+s4.getName());
        staticVariable.father();
        System.out.println();

        staticVariable.father="ali";
        System.out.println("1st person wife  data");
        System.out.println("id id:"+s5.getId()+"\nname is : "+s5.getName());
        staticVariable.father();
        System.out.println();

        staticVariable.counter();
        System.out.println("for testing sasur of 1st person is ....");
        staticVariable.father();

    }
}
