package com.programs_practice;

public class Address {
     private String town;
     private String city;
     private  String street;

    public Address(String town, String city, String street) {
        this.town = town;
        this.city = city;
        this.street = street;
    }

    public String getTown() {
        return town;
    }

    public void setTown(String town) {
        this.town = town;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }
}
