package com.programs_practice;

public class staticVariable {
    private  String name;
    private  int id;
    static int counter;
    static String  father;

    public staticVariable(String name,int id) {
        this.id=id;
        this.name=name;
        counter++;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
    public void diplay(){
        System.out.println(name);
        System.out.println(father);
        System.out.println(id);
    }

    public static void counter(){
        System.out.println("number of objects to be ccreated  = "+counter);
    }
    public static void father(){
        System.out.println("father is : "+ father);

    }

}
