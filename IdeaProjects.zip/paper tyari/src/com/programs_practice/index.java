package com.programs_practice;

public class index {
    public static void max(int[] a){
        int max= a[0];
        int index=0;
        for (int i = 0; i < a.length; i++) {
            if (a[i] > max) {
                max = a[i];
                index= index+i+1;
            }

        }
        System.out.println("max value "+max+" at index "+index);
    }
    public static void min(int[] a){
        int min= a[0];
        int index=0;
        for (int i = 0; i < a.length; i++) {
            if (a[i] < min){
                min = a[i];
                index = index+i+1;
        }}
        System.out.println("max value "+min+" at index "+index);
    }

}
