package com.programs_practice;

public class Employe {
    private int id;
    private String name;
    private Address address1;

    public Employe(int id , String name ) {
        this.id=id;
        this.name=name;
    }

    public Employe(int id, String name, Address address1) {
        this(id,name);
         this.address1=address1;
    }

    public Address getAddress1() {
        return address1;
    }

    public void setAddress1(Address address1) {
        this.address1 = address1;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
