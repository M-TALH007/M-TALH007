package com.programs_practice;

public class gradeBook {
    private String courseName;
    int grades[];

    public gradeBook(String courseName, int[] grades) {
        this.courseName = courseName;
        this.grades = grades;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }
    public void processGrade(){
        outputGrades();
        outputBarChart();
        average();
        Max();
        Min();

    }
    public void average(){
        int total=0;
        for (int grade :grades){
            total=total+grade;
        }
        System.out.println( "the average is "+ total/grades.length);
    }
    public void Max(){
        int lowGrade=grades[0];
        for (int i: grades) {
            if (i>lowGrade){
                lowGrade=i;
            }

        }
        System.out.println("the max value is "+lowGrade);
    }
    public void Min(){
        int highGrade=grades[0];
        for (int grade: grades ) {
            if (grade<highGrade){
                highGrade=grade;
            }

        }
        System.out.println("the min value is "+highGrade);
    }
    public void outputGrades(){
        System.out.println(" the grades are: ");
        for (int students = 0; students < grades.length; students++) {
            System.out.printf("student %d: %d%n", students + 1, grades[students]);
        }
    }
    public void outputBarChart(){
        System.out.println("grade Distribution :");
        int[] frequency=new int[11];
        for (int grade:grades){
            ++frequency[grade/10];
        }

        for (int roll = 0; roll < frequency.length; roll++) {
            if (roll==10)
                System.out.printf("%d :", 100);
            else
                System.out.printf("%02d-%02d: ",roll*10,roll*10+9);

        for (int stars = 0; stars < frequency[roll]; stars++) {
            System.out.print("*");
        }
            System.out.println();



        }
    }
}

