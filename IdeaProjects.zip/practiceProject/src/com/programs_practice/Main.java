package com.programs_practice;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        Login l=new Login();
        l.setVisible(true);
        l.setSize(600,600);
        l.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}
