package com.programs_practice;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Scanner;

public class Login extends JFrame {
    private JButton login;
    private JTextField user;
    private JPasswordField pass;
    private JLabel l1,l2;
    private Box b;
    Scanner sc;




    public Login() {
        super("LOGIN FRAME");
        setLayout(new FlowLayout());

        b = Box.createVerticalBox();
        add(b);
        Box hb = Box.createHorizontalBox();
        b.add(hb);
        l1 = new JLabel("user name ");
        hb.add(l1);
        user = new JTextField(20);
        hb.add(user);
        Box hb2 = Box.createHorizontalBox();
        b.add(hb2);
        l2 = new JLabel("password");
        hb2.add(l2);
        pass = new JPasswordField(20);
        hb2.add(pass);
        login = new JButton("login ");
        b.add(login);

        login.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String usern = null;
                String passn = null;
                usern = user.getText();
                passn = pass.getText();
                String us = null;
                String ps = null;
                try {
                    sc = new Scanner("logindata.txt");
                    sc.useDelimiter("[,\n]");
                    while (sc.hasNext()) {
                        boolean p = passn.toString().equals(sc.next());
                        boolean u = usern.toString().equals(sc.next());

                        if (p && u) {
                            JOptionPane.showMessageDialog(null, "LOGIN CONFIRMED");
                        } else if (p == false && u == false)
                            JOptionPane.showMessageDialog(null, "INVALID CREDENTIALS");

                    }
                } catch (Exception ex) {
                    System.out.println("FILE NOT FOUND");
                }
            }
        });
    }

}