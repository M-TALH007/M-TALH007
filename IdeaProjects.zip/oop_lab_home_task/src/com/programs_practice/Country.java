package com.programs_practice;

import java.util.ArrayList;
import java.util.Arrays;

public class Country implements stats {
    private String name;
    private int[] provinceArea;
    private ArrayList<Integer> statesArea;

    public Country(String name, int[] provinceArea, ArrayList<Integer> statesArea) {
        this.name = name;
        this.provinceArea = provinceArea;
        this.statesArea = statesArea;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int[] getProvinceArea() {
        return provinceArea;
    }

    public void setProvinceArea(int[] provinceArea) {
        this.provinceArea = provinceArea;
    }

    public ArrayList<Integer> getStatesArea() {
        return statesArea;
    }

    public void setStatesArea(ArrayList<Integer> statesArea) {
        this.statesArea = statesArea;
    }

    @Override
    public void reset() {
        for (int pro : provinceArea){
            pro = 0;
    }
        statesArea.clear();
    }

    @Override
    public double area() {
        double states =0;
        double provinces=0;
        for(double pro :provinceArea)
            provinces=provinces+pro;
        for (double st:statesArea)
            states=states+st;
        return provinces+states;
    }

    @Override
    public String toString() {
        return "Country{" +
                "name='" + name + '\'' +
                ", provinceArea=" + Arrays.toString(provinceArea) +
                ", statesArea=" + statesArea +
                '}';
    }
}

