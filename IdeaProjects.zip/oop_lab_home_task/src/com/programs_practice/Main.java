package com.programs_practice;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void printStat(stats s){
            System.out.println("Area: "+s.area());
            s.reset();
        }

    public static void main(String[] args) {
        int province[] = new int[]{2, 3, 4, 5, 6};

        ArrayList<Integer> states = new ArrayList<>();
        states.add(5);
        states.add(10);
        states.add(20);
        states.add(30);

        stats[] stat = new stats[]{
                new rectangle("red", true, 20, 10),
                new square(10),
                new Country("China", province, states)
        };

        for (stats st : stat) {
            System.out.println(st);
            printStat(st);

        }

    }}
