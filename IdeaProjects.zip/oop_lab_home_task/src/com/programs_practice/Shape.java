package com.programs_practice;

public abstract class Shape implements stats {
    private String color;
    private boolean filed;

    public Shape(String color, boolean filed) {
        this.color = color;
        this.filed = filed;
    }

    public Shape() {
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public boolean isFiled() {
        return filed;
    }

    public void setFiled(boolean filed) {
        this.filed = filed;
    }


    @Override
    public String toString() {
        return "Shape{" +
                "color='" + color + '\'' +
                ", filed=" + filed +
                '}';
    }

}
