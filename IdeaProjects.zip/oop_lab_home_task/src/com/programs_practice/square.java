package com.programs_practice;

public class square extends rectangle{
    private double side;

    public square(){}

    public square(double side){
        this.side = side;
    }

    public square(String color, boolean filed, double width, double length, double side) {
        super(color, filed, width, length);
        this.side = side;
    }

    public double getSide() {
        return side;
    }

    public void setSide(double side) {
        this.side = side;
    }

    public double area(){
        return side*side;
    }

    @Override
    public double getLength() {
        return super.getLength();
    }

    @Override
    public void setLength(double length) {
        super.setLength(length);
    }

    @Override
    public String toString() {
        return "square{" +
                "side=" + side +
                '}';
    }
}
