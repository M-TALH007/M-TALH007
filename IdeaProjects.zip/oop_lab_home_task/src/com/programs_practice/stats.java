package com.programs_practice;

public interface stats {
    public String units = "sq.km";
    public double area();
    public void reset();
}
