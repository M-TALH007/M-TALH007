package com.programs_practice;

public class Circle extends Shape {
    private  double radius;

    public Circle(String color, boolean filed, double radius) {
        super(color, filed);
        this.radius = radius;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }
    public double getArea(){
        return 0;
    }
    public  double getPerimeter(){
        return 0;
    }

    @Override
    public double area() {
        return 0;
    }

    @Override
    public void reset() {
        setRadius(0);
    }

    @Override
    public String toString() {
        return "Circle{" +
                "radius=" + radius +
                '}';
    }
}
