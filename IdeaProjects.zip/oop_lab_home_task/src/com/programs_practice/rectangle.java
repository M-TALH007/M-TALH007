package com.programs_practice;

public class rectangle extends Shape{
private double width;
private double length;

    public rectangle(String color, boolean filed, double width, double length) {
        super(color, filed);
        this.width = width;
        this.length = length;
    }

    public rectangle(){}

    public rectangle(double width, double length) {
        this.width = width;
        this.length = length;
    }

    @Override
    public double area() {
     return getArea();
    }

    @Override
    public void reset() {
        setLength(0);
        setWidth(0);
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }
    public double getArea(){
        return getLength()*getLength();
    }
    public double getPerimeter(){
        return 2*(getLength()+getWidth());

    }

    @Override
    public String toString() {
        return "rectangle{" +
                "width=" + width +
                ", length=" + length +
                '}';
    }
}
