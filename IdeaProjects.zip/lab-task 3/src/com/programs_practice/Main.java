package com.programs_practice;

import java.time.LocalDate;

public class Main {

    public static void main(String[] args) {

        //                          part 1
        //=======================================================================================
	/*Radius r = new Radius(3.4);
    r.setRadius(1);
        System.out.println("the radius of circle is: " +r.getRadius()+"\n"+
                "the area of a circle is :"+r.area()+"\n"+
                "the perimeter of a circle is :"+r.perimeter());*/
/*
        // task 2
        // ===================================================================================
        Employee employee=new Employee();
        Employee employee1=new Employee(35302-1111111-2,"ali");
        employee1.setCnic(35302-99299992-1);
        employee1.setName("falak sher");

        Employee employee2 = new Employee(34002-223452-2,"ahmad",120000);
        System.out.println("employee salary is "+employee.getSalary()+
                " employee cnic "+employee.getCnic()+" employee name is "+employee.getName());
        System.out.println("employee1 salary is "+employee1.getSalary()+
                " employee1 cnic "+employee1.getCnic()+" employee1 name is "+employee1.getName());
        System.out.println("employee2 salary is "+employee2.getSalary()+
                " employee2 cnic "+employee2.getCnic()+" employee2 name is "+employee2.getName());
*/
/*
        // ================================================================
        //task 3

        Account acc = new Account(35202-23323-3, 21, "talha");
        Account acc1= new Account(8789-33683-3, 28, "ali");
        Account acc2 = new Account(73674-343983-3, 45, "ahmed");
        Account acc3 = new Account(323233-3334983-3, 19, "abid");
        acc.withdraw(5000);
        acc1.withdraw(5000);
        //acc2.withdraw(5000);
        //acc3.withdraw(5000);
        acc.deposit(1000);
        acc1.deposit(1000);
        //acc2.deposit(1000);
        acc3.deposit(1000);

        System.out.println("age "+acc.getAge()+" "+"balance: "+acc.getBalance()+" name: "+acc.getName());
        System.out.println("age "+acc1.getAge()+" "+"balance: "+acc1.getBalance()+" name: "+acc1.getName());
        System.out.println("age "+acc2.getAge()+" "+"balance: "+acc2.getBalance()+" name: "+acc2.getName());
        System.out.println("age "+acc3.getAge()+" "+"balance: "+acc3.getBalance()+" name: "+acc3.getName());


*/

           // =========================================================================
           //task 4
        Person person = new Person("Ali" ,19); //First constructor is used here
        //person2 is created with Second Constructor
        Person person1 = new Person("talha", LocalDate.of(2002, 6, 4));
                      //note how i used LocalDate.of to pass a LocalDate object to function

        person1.setHeight(5);
        person.setHeight(7);
        person1.setWeight(58);
        person.setWeight(57);
        System.out.printf("BMI of talha is "+ person1.getBMI());
        System.out.println("\nHeight of talha is "+person1.getHeight()+"ft");
        System.out.println("Weight of talha is "+person1.getWeight()+"km");
        System.out.println("age of talha is "+person.getAge());
        System.out.println("year of born is "+person.DOB.getYear());
        System.out.println("year of date is "+person.DOB.getDayOfMonth());

        System.out.println("year of date is "+person.DOB.getMonth());
        System.out.println("year of date is "+person.DOB);













    }
}
