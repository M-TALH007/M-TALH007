package com.programs_practice;

public class Account {


    private int accountId;
    private int cnic;
    private int age;
    private String name;
    private double balance;

    public Account( int cnic, int age, String name) {
        if(age > 35)
        this.balance = 0;
        else if(age >= 20 && age < 25)
            balance = 50000;
        else if(age >= 25 && age < 30)
            this.balance = 25000;
        else if(age >= 30 && age <= 35)
            this.balance = 10000;
        else {
            System.out.println("account cannot be created if age is less than 20");
            return;
        }
        this.cnic = cnic;
        this.age = age;
        this.name = name;
    }


    public int getCnic() {
        return cnic;
    }

    public void setCnic(int cnic) {
        this.cnic = cnic;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
    public void deposit(double amount){
        if(amount > 0)
            balance += amount;
        else {
            System.out.println("something went wrong");
        }
    }

    public void withdraw(double amount) {
        if (amount > 0)
            balance -= amount;
        if(amount>0)
             System.out.println("withdrawn successfully");
        else
             System.out.println("withdrawn not successfully");
        return;
    }
}
