package com.programs_practice;
import java.time.LocalDate;
public class Person {

        LocalDate DOB; //date of birth
         private String name;
        private double height;
        private int age;
       private double weight;


        Person(String name, int age){
            this.name = name;
            if(age > 0)
                DOB = LocalDate.now().minusYears(age);
            else System.out.println("age is not negative");
        }

        Person(String name, LocalDate dob){
            this.name = name;
            this.DOB = DOB;
        }

        public void setHeight(double height){
            this.height = height;
        }
        public void setWeight(double weight){
            this.weight = weight;
        }

        public int getAge(){
            LocalDate today = LocalDate.now();
            int todayYear = today.getYear();
            int yearYouWereBorn = DOB.getYear();
            return todayYear - yearYouWereBorn;
        }
        public String getName(){
            return name;
        }
        public double getHeight(){
            return height;
        }
        public double getWeight(){
            return weight;
        }
        public double getBMI(){

            if(getHeight() != 0 && getWeight() != 0)
                return getWeight() / getHeight() / getHeight() * 10000;
            else {
                System.out.println("Weight and Height not provided");
                return -1;
            }
        }
        public void getBMIHelp(){
            System.out.println("Underweight =< 16.5\nNormal Weight = 18.5 - 24.9\n" +
                    "Overweight = 25 - 29.9\nObesity >= 30");
        }
    }


