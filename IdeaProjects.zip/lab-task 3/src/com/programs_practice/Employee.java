package com.programs_practice;

public class Employee {
    private int cnic;
    private String name;
    private double salary;
    public Employee(){
        this.cnic=35302-00000000-1;
        this.name="talha";
        this.salary=100000;
    }
    public Employee(int cnic,String name){
        this.cnic=cnic;
        this.name=name;
         this.salary=130000;
    }

    public Employee(int cnic, String name, double salary) {
        this(cnic, name);
        this.cnic = cnic;
        this.name = name;
        this.salary = salary;
    }

    public int getCnic() {
        return cnic;
    }

    public void setCnic(int cnic) {
        this.cnic = cnic;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
}
