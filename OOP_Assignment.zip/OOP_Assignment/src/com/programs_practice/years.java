package com.programs_practice;

public enum years {
    ONE(0.1,1),
    THREE(0.12,3),
    FIVE(0.14,5);

    private double profit;
    private double years;


    years(double profit,  double years) {
        this.profit = profit;
        this.years = years;
    }

    public double getProfit() {
        return profit;
    }

    public double getYears() {
        return years;
    }
}
