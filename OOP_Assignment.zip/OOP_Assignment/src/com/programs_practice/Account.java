package com.programs_practice;

import java.util.ArrayList;

public abstract class Account {
    private  int age;
    private double amount;
    private String name;
    private int id;
    private boolean zakat;



    public Account(int age, double amount, String name, int id, boolean zakat) {
        this.age = age;
        this.amount = amount;
        this.name = name;
        this.id = id;
        this.zakat = zakat;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public  double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public abstract void withdraw(double WAmount);
    public abstract void deposit(double DAmount);
    public abstract double balanceCheck();
    public abstract double zakatDeduction(double ZAmount);
    public abstract double TotalEarning();

    public static double totalProfit(ArrayList<Account> accounts){
        double totalProfitPaid = 0;
        for(Account currentAccount:accounts){
            totalProfitPaid += currentAccount.TotalEarning();
        }
        return totalProfitPaid;
    }




    @Override
    public String toString() {
        return "Account{" +
                "age=" + age +
                ", amount=" + amount +
                ", name='" + name + '\'' +
                ", id=" + id +
                ", zakat=" + zakat +
                '}';
    }
}
