package com.programs_practice;

public class Current_Account extends Account{
    public Current_Account(int age, double amount, String name, int id, boolean zakat) {
        super(age, amount, name, id, zakat);
    }

    @Override
    public void withdraw(double WAmount) {
        super.setAmount(super.getAmount()-WAmount);
        System.out.println("withdraw amount ="+WAmount);
    }

    @Override
    public void deposit(double DAmount) {
        super.setAmount(super.getAmount()+DAmount);
        System.out.println("Amount deposit = "+DAmount);

    }

    @Override
    public double zakatDeduction(double ZAmount) {
        ZAmount = getAmount()-(getAmount()*0.025);
        return ZAmount;
    }

    @Override
    public double TotalEarning() {
        return 0;
    }

    @Override
    public double balanceCheck() {
       return getAmount();
    }

    @Override
    public String toString() {
        return "Current_Account: "+super.toString();
    }
}
