import java.sql.SQLOutput;
import java.util.Scanner;

public class SavingsAccount extends EarningAccount{

    //constructor
    public SavingsAccount(double openingBalance, String name, int age, boolean zakat, boolean filer) {
        super(openingBalance, name, age, zakat, filer);
    }

    @Override
    public void withdraw(double withdrawAmount) {
        super.setOpeningBalance(super.getOpeningBalance() - withdrawAmount); //subtracting the withdrawn amount from original amount
        System.out.println(" Amount Withdrawn = "+withdrawAmount);
    }

    @Override
    public void deposit(double depositAmount) {
        super.setOpeningBalance(super.getOpeningBalance() + depositAmount); //adding the deposit amount to original amount
        System.out.println(" Amount Deposited = "+depositAmount);
    }

    @Override
    public double checkBalance() {
        if(super.isZakat()){
            super.setOpeningBalance(deductZakat(super.getOpeningBalance()));
        }
        return super.getOpeningBalance();
    }

    @Override
    public double getTotalEarnings() {

        double totalProfit = super.getOpeningBalance() * super.getCategory().getProfit();;/*getting profit by multiplying the original amount by the percent
                                                                                      amount stored in each 'Category' enum */

        if(super.isFiler()){ //deducting 15% tax if user is a filer
            totalProfit = totalProfit - (totalProfit * 0.15);
        }
        else //deducting 25% tax if user is not a filer
            totalProfit = totalProfit - (totalProfit * 0.25);



        return totalProfit;
    }

    //method to reinvest the earnings
    @Override
    public void reinvestProfit(double profitEarned){
        Scanner input = new Scanner(System.in);
        System.out.println(" Do you want to reinvest the earnings?\n Press 1 to reinvest or Press 0 if not"); //asking user if he wants to deposit the profit
        int choice = input.nextInt();
        if(choice == 1){
            deposit(profitEarned);
        }
    }

    //method to deduct zakat
    @Override
    public double deductZakat(double amountToDeductZakatFrom){
        double amountToBeDeducted = super.getOpeningBalance() * 0.025;
        amountToDeductZakatFrom -= amountToBeDeducted;
        System.out.println(" Zakat Deducted = "+amountToBeDeducted);
        return amountToDeductZakatFrom;
    }

    //toString method
    public String toString(){
        return String.format("%n%n<========== Savings Account ==========>%s",super.toString());
    }
}
