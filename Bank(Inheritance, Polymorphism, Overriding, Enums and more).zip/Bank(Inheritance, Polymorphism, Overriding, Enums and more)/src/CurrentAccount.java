public class CurrentAccount extends Account{

    //constructors
    public CurrentAccount() {
    }

    public CurrentAccount(double openingBalance, String name, int age, boolean zakat) {
        super(openingBalance, name, age, zakat);
    }

    @Override
    public void withdraw(double withdrawAmount) {
        super.setOpeningBalance(super.getOpeningBalance() - withdrawAmount); //subtracting the withdrawn amount from original amount
        System.out.println("Amount Withdrawn = "+withdrawAmount);
    }

    @Override
    public void deposit(double depositAmount) {
        super.setOpeningBalance(super.getOpeningBalance() + depositAmount); //adding the deposit amount to original amount
        System.out.println("Amount Deposited = "+depositAmount);
    }

    @Override
    public double checkBalance() {
        if(super.isZakat()){
            super.setOpeningBalance(deductZakat(super.getOpeningBalance()));
        }
        return super.getOpeningBalance();
    }

    public  double getTotalEarnings(){
        return 0;
    }

    //method to deduct zakat
    @Override
    public double deductZakat(double amountToDeductZakatFrom){
        amountToDeductZakatFrom = amountToDeductZakatFrom - (amountToDeductZakatFrom * 0.025);
        return amountToDeductZakatFrom;
    }

    //toString method
    @Override
    public String toString(){
        return String.format("%n%n<========== Current Account ==========>%s",super.toString());
    }

}
