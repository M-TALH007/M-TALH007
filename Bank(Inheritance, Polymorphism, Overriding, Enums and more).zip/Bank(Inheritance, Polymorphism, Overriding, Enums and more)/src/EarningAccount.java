public abstract class EarningAccount extends Account {

    //instance variables
    private Category category;
    private boolean filer;

    //constructors
    public EarningAccount(double openingBalance, String name, int age, boolean zakat,boolean filer) {
        super(openingBalance, name, age, zakat);
        this.filer = filer;
        category = setCategory();
    }


    //method to set category
    public Category setCategory(){
        if(super.getAge()<35){
            return Category.YOUNG;
        }
        else if(super.getAge()>=35 && super.getAge()<=50){
            return Category.ADULT;
        }
        else if(super.getAge()>50){
             return Category.SENIOR;
        }
        else
            return null;
    }

    //method to get category
    public Category getCategory() {
        return category;
    }

    //setter and getter for filer
    public boolean isFiler() {
        return filer;
    }

    public void setFiler(boolean filer) {
        this.filer = filer;
    }

    //abstract method
    public abstract double getTotalEarnings();
    public abstract double deductZakat(double total);
    public abstract void reinvestProfit(double profitEarned);

    //toString Method
    public String toString(){
        return String.format("%n Account Category: %s%n %s%n Filer Status: %s",category.getName(),super.toString(),filer);
    }

}
