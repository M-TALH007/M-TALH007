public class AccountTest {

    public static void main(String[] args) {
        Account[] accounts = new Account[]{
                new SavingsAccount(100000,"Ibrahim",20,true,true),
                new CurrentAccount(150000,"Ahmed",35,true),
                new InvestmentAccount(200000,"Ali",51,false,true)

        };

        for(Account account:accounts){
            System.out.println(account);
            double totalEarnings = account.getTotalEarnings();
            System.out.printf(" Total Earnings: %.2f",totalEarnings);
            if(account instanceof EarningAccount){
                EarningAccount temp = (EarningAccount) account;
                temp.reinvestProfit(totalEarnings);
            }

        }
        System.out.printf("%n Total Profit Paid by the Bank: %.2f ",Account.getTotalPaidProfit(accounts));
    }
}
