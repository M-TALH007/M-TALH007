import java.util.Scanner;

public class InvestmentAccount extends EarningAccount{

    //instance variables
    Type accountType;


    //constructor
    public InvestmentAccount(double openingBalance, String name, int age, boolean zakat, boolean filer) {
        super(openingBalance, name, age, zakat, filer);
        accountType = setAccountType();
    }

    @Override
    public void withdraw(double withdrawAmount) {
        double surcharge = withdrawAmount * 0.04; //surcharge is deducted from investment accounts when withdraw is made
        super.setOpeningBalance(super.getOpeningBalance() - withdrawAmount - surcharge); //subtracting the withdrawn amount and surcharge from original amount
        System.out.println(" Amount Withdrawn = "+withdrawAmount);
        System.out.println(" Surcharge Amount Deducted: "+ surcharge);

    }

    @Override
    public void deposit(double depositAmount) {
        super.setOpeningBalance(super.getOpeningBalance() + depositAmount); //adding the deposit amount to original amount
        System.out.println(" Amount Deposited = "+depositAmount);
    }

    @Override
    public double checkBalance() {
        if(super.isZakat()){
            super.setOpeningBalance(deductZakat(super.getOpeningBalance()));
        }
        return super.getOpeningBalance();
    }

    @Override
    public double getTotalEarnings() {
        Scanner input = new Scanner(System.in);
        double totalProfit = super.getOpeningBalance() * super.getCategory().getProfit();;/*getting profit by multiplying the original amount by the percent
                                                                                      amount stored in each 'Category' enum */
        double amountIncreasePerYear = 0;
        for (int i = 0; i < accountType.getYears(); i++) {
            amountIncreasePerYear = super.getOpeningBalance() * accountType.getProfit();
            super.setOpeningBalance(super.getOpeningBalance()+amountIncreasePerYear);
            totalProfit += amountIncreasePerYear;
        }

        /*Logic for above loop :
        * We iterate the loop according to years stored in enum 'Type'.
        * We get the total profit per year by multiplying original opening balance with profit based on the account type(enum that already has
          profit predefined for every account
        * We also increase the original opening balance with the profit so that next year profit can be calculated according to this amount
        * Then we finally increase the total(which is the total profit an account earns) by adding it with current year profit  */

        if(super.isFiler()){ //deducting 15% tax if user is a filer
            totalProfit = totalProfit - (totalProfit * 0.15);
        }
        else //deducting 25% tax if user is not a filer
            totalProfit = totalProfit - (totalProfit * 0.25);

        return totalProfit;
    }

    //method to reinvest the earnings
    @Override
    public void reinvestProfit(double profitEarned){
        Scanner input = new Scanner(System.in);
        System.out.println(" Do you want to reinvest the earnings?\n Press 1 to reinvest or Press 0 if not"); //asking user if he wants to deposit the profit
        int choice = input.nextInt();
        if(choice == 1){
            deposit(profitEarned);
        }
    }

    //method to deduct zakat
    @Override
    public double deductZakat(double amountToDeductZakatFrom){
        double amountToBeDeducted = super.getOpeningBalance() * 0.025;
        amountToDeductZakatFrom -= amountToBeDeducted;
        System.out.println("Zakat Deducted = "+amountToBeDeducted);
        return amountToDeductZakatFrom;
    }

    //method to set the type of account

    public Type setAccountType(){
        Scanner input = new Scanner(System.in);
        int choice;
        System.out.println("Please choose type of account below: \n1.One Year Account\n2.Three Year Account\n3.Five Year Account");
        choice = input.nextInt();

        switch (choice){  //switch case to check the choice
            case 1:
                return Type.ONE;
            case 2:
                return Type.THREE;
            case 3:
                return Type.FIVE;
            default:
                System.out.println("Please choose a valid option!");
                break;
        }
        return null;
    }

    //toString Method
    @Override
    public String toString(){
        return String.format("%n%n<========== Investment Account ==========>%n Account Type: %s%n %s",accountType.getName(),super.toString());
    }

}


